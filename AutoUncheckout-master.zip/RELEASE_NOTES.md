#### 1.1 2014-08-29
* (Fix) If file merged undo not necessary

#### 1.0 2014-06-05
* Initial Release
