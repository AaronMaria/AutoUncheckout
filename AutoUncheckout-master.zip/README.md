# Auto Uncheckout

Small Visual Studio extension, but usefull for server workspace of TFS. Automatically undo check out file after save, if it has not been modified.

## Usage
Just install it.

## Issues
[https://github.com/CDuke/AutoUncheckout/issues](https://github.com/CDuke/AutoUncheckout/issues)

## Visual Studio Gallery
[Auto Uncheckout](http://visualstudiogallery.msdn.microsoft.com/f58f3eae-e406-48c7-adc0-58b9772bbd74)